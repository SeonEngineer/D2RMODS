스킨의 명칭의 이름을 변경하였습니다.
반드시 배틀넷 명령 인자를 수정해주세요

D2R스킨:
 -mod seonhee -txt -lowend

구디아2번역스킨:
 -mod seonheeLegacy -txt -lowend


변경이유
 Estia님이 처음으로 -mod 인자를 적용하는 방법을 알려주셔서 이에 감사하여 그대로 이름을 사용하였습니다만, 이게 Estia님 스킨으로 착각하는 일이 벌어져 더이상의 오인을 막기위해 삭제하였습니다

제작
dogdrip.net VEngineer (선히@인벤)