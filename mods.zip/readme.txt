자꾸 패치를 번복해서 죄송합니다 불편하다고 하시는 항목들을 다시 뜯어고쳤습니다.
제스킨만 사용하시는분들은 폴더를 싹 삭제하신다음에 설치해주시면 감사하겠습니다.
아이템 이름등은 건들지않았으니 item~.json을 수정하신분은 수정하신 파일을 백업하시고 설치해주세요


0. D2R폴더 내에 압축을 풀어주세요. 압축을 풀었을때 (C드라이브에 설치했다면) *드라이브 위치는 상관없습니다
C:/Program Files (x86)/Diablo II Resurrected/mods/seonhee
C:/Program Files (x86)/Diablo II Resurrected/mods/seonheeLegacy
D2R폴더/mods 폴더안에 seonhee, seonheeLegacy 두개의 폴더가 있어야합니다.


1. 배틀넷 런처 인자에서
[설정](동그란 톱니바퀴) → 게임설정 → 새로 뜨는창 중간에 [명령줄 인수 추가] 를 선택하시고 아래 명령어를 입력하세요
 -mod seonhee -txt
를 입력해주세요.

구디아2번역 모드로 사용하실분은
 -mod seonheeLegacy -txt
로 시작해주세요.


2. 원하는 아이템의 글자를 바꾸고싶으시다면
/data/local/lng/strings/ 폴더내에, item~이름이 붙은.json 파일들이 있습니다.
메모장으로 열으셔서 원하시는 글자를 검색하신 후에 편집후 닫아주세요.
(예시가 궁금하시면 "활력" 으로 검색하셔서 활력 물약을 보시면됩니다"


3. 폰트를 바꾸고싶다면
/data/hd/ui/fonts/ 폴더안에 원하시는 폰트를 이름을 바꿔넣어주세요
파일명은 텍스트 해당폴더에 있는 텍스트파일을 참고해주세요
kodia.ttf만 넣어주셔도 대부분 바뀌지만 바뀌지않는 텍스트도 있으므로 통째로 바꿔주시면 좋습니다


4. 호라드릭 함 스킨을 지우고싶다면, 아래 경로에있는 파일을 삭제해주세요
(레저렉션)/data/hd/global/ui/panel/horadric_cube/horadriccube_bg.sprite (+horadriccube_bg.lowend.sprite)
(컨트롤러)/data/hd/global/ui/controller/panel/horadriccube/v2/horadriccubebg.sprite (+horadriccubebg.lowend.sprite)
(구버전) /data/global/ui/panel/supertransmogrifier.dc6


4. 부가설명(도움말,소지품창)에 뜨는 스킨을 지우고싶다면
/data/hd/global/ui/panel/ 폴더안에있는 seonhee_hud1.sprite ~ seonhee_hud10.sprite 파일을 모두 지워주세요
 4-1. 인벤토리만 지우고싶다면 아래경로 파일을 지워주세요
  (레저렉션) /data/global/ui/layouts/playerinventoryexpansionlayouthd.json
  (컨트롤러) /data/global/ui/layouts/controller/playerinventoryexpansionlayouthd.json


※5. 더이상 사용하지않는 파일입니다 (타 스킨과 함께 사용하시는 경우 지우셔야 정상작동 할 수 있음)
/data/global/ui/layouts/controller/horadriccubelayouthd.json
/data/global/ui/layouts/controller/controlleroverlayhd.json
/data/global/ui/layouts/characterstatspanelhd.json
/data/global/ui/layouts/gameplayoptionspanelhd.json
/data/global/ui/layouts/horadriccubelayouthd.json
/data/global/ui/layouts/hudpanelhd.json
/data/global/ui/layouts/questlogpaneloriginalhd.json